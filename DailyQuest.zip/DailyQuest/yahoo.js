'use strict';
(() => {
  const clientId = 'dmVyPTIwMjUwNyZpZD1iZ0Y4V0NoUlZPJmhhc2g9WkdGbVl6SmlOR0ZrTW1Vek5UVmhZUQ';
  function requireId(status) {
    status.classList.remove('api-error');
    return true;
  }
  function enableCredit() { $('yahooCredit').hidden = false; }
  function addQuest(title, category, description) {
    window.addDailyQuestMission({ id: `yahoo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, title, category, description, xp: 20 });
  }
  function safeUrl(value) { try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.href : ''; } catch { return ''; } }
  $('searchProducts').addEventListener('click', async () => {
    const status = $('productStatus'), results = $('productResults'), query = $('productQuery').value.trim();
    results.replaceChildren(); if (!requireId(status)) return;
    if (!query) { status.textContent = '検索キーワードを入力してください。'; return; }
    status.textContent = 'Yahoo!ショッピングへ検索しています…'; enableCredit();
    const url = new URL('https://shopping.yahooapis.jp/ShoppingWebService/V3/itemSearch');
    url.searchParams.set('appid', clientId); url.searchParams.set('query', query); url.searchParams.set('results', '10');
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(response.status === 429 ? '利用上限に達しました（HTTP 429）。時間をおいて再試行してください。' : `Yahoo! APIがHTTP ${response.status}を返しました。`);
      const data = await response.json();
      const hits = Array.isArray(data.hits) ? data.hits : [];
      if (!hits.length) { status.textContent = '該当する商品はありませんでした。'; return; }
      status.textContent = `${hits.length}件の実際の検索結果`;
      for (const item of hits) {
        const card = document.createElement('article'); card.className = 'api-result';
        const image = safeUrl(item.image?.medium || item.image?.small || '');
        if (image) { const img = document.createElement('img'); img.src = image; img.alt = ''; img.loading = 'lazy'; card.append(img); } else { const spacer = document.createElement('span'); card.append(spacer); }
        const body = document.createElement('div');
        const link = document.createElement('a'); link.href = safeUrl(item.url) || '#'; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = item.name || '商品ページ'; body.append(link);
        const price = document.createElement('p'); price.textContent = item.price ? `${Number(item.price).toLocaleString('ja-JP')}円` : '価格情報なし'; body.append(price);
        if (item.seller?.name) { const seller = document.createElement('p'); seller.textContent = `販売：${item.seller.name}`; body.append(seller); }
        const button = document.createElement('button'); button.type = 'button'; button.className = 'button-secondary'; button.textContent = '買い物クエストに追加'; button.addEventListener('click', () => addQuest(`商品を探す：${item.name || query}`, '買い物', 'Yahoo!ショッピングの検索結果から追加')); body.append(button); card.append(body); results.append(card);
      }
    } catch (error) {
      status.textContent = error instanceof TypeError ? '通信に失敗しました。ブラウザーのCORS制限、ネットワーク、またはClient IDを確認してください。この静的アプリからの直接通信が許可されない場合は中継サーバーが必要です。' : error.message;
      status.classList.add('api-error');
    }
  });
  function jsonp(endpoint, params) {
    return new Promise((resolve, reject) => {
      const callback = `dailyQuestYolp${Date.now()}${Math.random().toString(36).slice(2, 7)}`;
      const script = document.createElement('script'); const url = new URL(endpoint);
      Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
      url.searchParams.set('appid', clientId); url.searchParams.set('output', 'json'); url.searchParams.set('callback', callback);
      const timer = setTimeout(() => finish(new Error('応答がタイムアウトしました。')), 15000);
      function finish(error, data) { clearTimeout(timer); delete window[callback]; script.remove(); error ? reject(error) : resolve(data); }
      window[callback] = data => finish(null, data);
      script.onerror = () => finish(new Error('YOLPへ接続できませんでした。API提供状況、Client ID、ネットワークを確認してください。'));
      script.src = url.href; document.head.append(script);
    });
  }
  function features(data) { const f = data?.YDF?.Feature; return !f ? [] : (Array.isArray(f) ? f : [f]); }
  $('searchPlaces').addEventListener('click', async () => {
    const status = $('placeStatus'), results = $('placeResults'), prefecture = $('mapPrefecture').value, municipality = $('mapMunicipality').value, address = [prefecture, municipality].filter(Boolean).join(''), query = $('placeQuery').value.trim();
    results.replaceChildren(); if (!requireId(status)) return;
    if (!address || !query) { status.textContent = '住所と施設の種類・名前を入力してください。'; return; }
    status.textContent = '住所と検索語をYahoo!へ送信しています…'; enableCredit();
    try {
      const geo = await jsonp('https://map.yahooapis.jp/geocode/V1/geoCoder', { query: address });
      const point = features(geo)[0]?.Geometry?.Coordinates;
      if (!point) throw new Error('住所から位置を特定できませんでした。住所を詳しく入力してください。');
      const [lon, lat] = point.split(',');
      const data = await jsonp('https://map.yahooapis.jp/search/local/V1/localSearch', { query, lat, lon, dist: '3', detail: 'full' });
      const found = features(data);
      if (!found.length) { status.textContent = '周辺に該当する施設はありませんでした。'; return; }
      status.textContent = `${found.length}件の実際の検索結果`;
      for (const place of found) {
        const name = place.Name || '名称なし', addr = place.Property?.Address || '';
        const card = document.createElement('article'); card.className = 'api-result';
        const marker = document.createElement('span'); marker.textContent = '📍'; marker.setAttribute('aria-hidden', 'true');
        const body = document.createElement('div'), title = document.createElement('strong'); title.textContent = name; body.append(title);
        const mapLink = document.createElement('a'); mapLink.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent([name, addr].filter(Boolean).join(' ')); mapLink.target = '_blank'; mapLink.rel = 'noopener noreferrer'; mapLink.textContent = 'Googleマップで開く'; body.append(mapLink);
        const addressLine = document.createElement('p'); addressLine.textContent = addr; body.append(addressLine);
        const button = document.createElement('button'); button.type = 'button'; button.className = 'button-secondary'; button.textContent = 'お出かけクエストに追加'; button.addEventListener('click', () => addQuest(`行ってみよう：${name}`, 'お出かけ', addr ? `住所：${addr}` : `検索地点：${address}`)); body.append(button); card.append(marker, body); results.append(card);
      }
    } catch (error) { status.textContent = error.message; status.classList.add('api-error'); }
  });
})();