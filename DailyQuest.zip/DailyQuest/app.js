'use strict';

const STORAGE_KEY = 'dailyQuest.v1';
const CATEGORIES = {
  '健康': '✦', '家事': '⌂', '料理': '♨', '学び': '✧',
  'お出かけ': '➶', '買い物': '▣', '自分時間': '☾', 'その他': '◇'
};
const DEFAULT_MISSIONS = [
  { id: 'walk', title: '近所を15分散歩する', category: '健康', description: '少し外の空気を吸って、体を目覚めさせよう。', xp: 20 },
  { id: 'tidy', title: '部屋の一角を片付ける', category: '家事', description: '机の上だけでも大丈夫。小さな場所を整えよう。', xp: 20 },
  { id: 'cook', title: '新しい料理をひとつ作る', category: '料理', description: 'いつもの食卓に、ちょっとした発見を。', xp: 30 },
  { id: 'read', title: '本を10ページ読む', category: '学び', description: '気になっていた本を開いてみよう。', xp: 20 },
  { id: 'stretch', period: 'daily', title: '5分間ストレッチをする', category: '健康', description: '深呼吸しながら、ゆっくり体を伸ばそう。', xp: 15 },
  { id: 'outside', period: 'weekly', title: '行ったことのない道を歩く', category: 'お出かけ', description: '近所に新しい景色を見つけに行こう。', xp: 25 },
  { id: 'water', period: 'weekly', title: '植物に水をあげる', category: '家事', description: '身近な緑の様子を見て、少し手入れしよう。', xp: 15 },
  { id: 'journal', period: 'weekly', title: '今日よかったことを3つ書く', category: '自分時間', description: '小さなことでも、うれしかったことを残そう。', xp: 20 },
  { id: 'learn', period: 'weekly', title: '新しいことを15分学ぶ', category: '学び', description: '動画でも記事でも、気になることをひとつ。', xp: 25 },
  { id: 'friend', period: 'weekly', title: '大切な人に連絡する', category: 'その他', description: '短いメッセージで、気持ちを届けよう。', xp: 15 }
];
const ACHIEVEMENTS = [
  { id: 'first', icon: '✦', title: '冒険のはじまり', detail: '最初のクエストを達成', test: s => s.completed.length >= 1 },
  { id: 'five', icon: '⚔', title: '小さな積み重ね', detail: '5つのクエストを達成', test: s => s.completed.length >= 5 },
  { id: 'ten', icon: '♛', title: '頼れる冒険者', detail: '10個のクエストを達成', test: s => s.completed.length >= 10 },
  { id: 'streak3', icon: '🔥', title: '三日坊主をこえて', detail: '3日連続でクエスト達成', test: s => s.streak >= 3 },
  { id: 'streak7', icon: '☀', title: '習慣の達人', detail: '7日連続でクエスト達成', test: s => s.streak >= 7 },
  { id: 'level5', icon: '⬆', title: 'レベル5到達', detail: '経験を重ねてレベル5へ', test: s => s.level >= 5 },
  { id: 'variety', icon: '🌈', title: '多彩な冒険', detail: '3カテゴリーのクエストを達成', test: s => s.categories.size >= 3 }
];
const $ = selector => document.querySelector(selector);
const $$ = selector => Array.from(document.querySelectorAll(selector));
let state = loadState();
let editingId = null;
let toastTimer;
const dialog = $('#missionDialog');

function normalizeMissions(items){return items.map((mission,index)=>({...mission,period:mission.period||(index<5?'daily':'weekly')}))}
function loadState(){
 try{const data=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');if(!data||data.version!==1)return {version:1,missions:normalizeMissions(structuredClone(DEFAULT_MISSIONS)),records:{},cycleLogs:[],questCycle:null,lightMode:false};return {version:1,missions:normalizeMissions(Array.isArray(data.missions)?data.missions:structuredClone(DEFAULT_MISSIONS)),records:data.records&&typeof data.records==='object'?data.records:{},cycleLogs:Array.isArray(data.cycleLogs)?data.cycleLogs:[],questCycle:data.questCycle||null,lightMode:Boolean(data.lightMode)}}catch(error){console.error('保存データの読み込みに失敗しました。',error);return {version:1,missions:normalizeMissions(structuredClone(DEFAULT_MISSIONS)),records:{},cycleLogs:[],questCycle:null,lightMode:false}}
}
function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); return true; }
  catch (error) { console.error('保存に失敗しました。', error); toast('保存できませんでした。ブラウザーの保存領域を確認してください。'); return false; }
}
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])); }
function dateKey(date = new Date()) { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
function weekKey(date=new Date()){const d=new Date(date.getFullYear(),date.getMonth(),date.getDate());d.setDate(d.getDate()-((d.getDay()+6)%7));return dateKey(d)}
function activeMissions(period){return state.missions.filter(m=>(m.period||'daily')===period).slice(0,5)}
function taskStatuses(period){return Object.fromEntries(activeMissions(period).map(m=>[m.id,'pending']))}
function ensureQuestCycles(){const today=dateKey(),week=weekKey();state.cycleLogs=Array.isArray(state.cycleLogs)?state.cycleLogs:[];if(!state.questCycle)state.questCycle={day:today,week,daily:{resetCount:0,tasks:taskStatuses('daily')},weekly:{tasks:taskStatuses('weekly')}};if(state.questCycle.day!==today)state.questCycle.daily={resetCount:0,tasks:taskStatuses('daily')};else{const p=state.questCycle.daily.tasks||{};state.questCycle.daily={resetCount:Number(state.questCycle.daily.resetCount)||0,tasks:Object.fromEntries(activeMissions('daily').map(m=>[m.id,p[m.id]||'pending']))}}if(state.questCycle.week!==week)state.questCycle.weekly={tasks:taskStatuses('weekly')};else{const p=state.questCycle.weekly.tasks||{};state.questCycle.weekly={tasks:Object.fromEntries(activeMissions('weekly').map(m=>[m.id,p[m.id]||'pending']))}}state.questCycle.day=today;state.questCycle.week=week}function formatDate(key, options = { month: 'numeric', day: 'numeric' }) {
  const [year, month, day] = key.split('-').map(Number);
  return new Intl.DateTimeFormat('ja-JP', options).format(new Date(year, month - 1, day));
}
function totalXp() { return Object.values(state.records).filter(record => record.status === 'completed').reduce((sum, record) => sum + Number(record.xp || 0), 0) + (state.cycleLogs||[]).reduce((sum,record)=>sum+Number(record.xp||0),0); }
function getCompleted() { return Object.entries(state.records).filter(([,record])=>record.status==='completed').concat((state.cycleLogs||[]).filter(record=>record.status==='completed').map(record=>[record.date,record])).sort(([a],[b])=>a.localeCompare(b)); }
function currentStreak() {

  const completedDates = new Set(getCompleted().map(([date,record]) => record.date || date));
  const today = dateKey();
  const yesterdayDate = new Date(); yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  let cursor = completedDates.has(today) ? new Date() : yesterdayDate;
  if (!completedDates.has(dateKey(cursor))) return 0;
  let streak = 0;
  while (completedDates.has(dateKey(cursor))) { streak++; cursor.setDate(cursor.getDate() - 1); }
  return streak;
}
function profileStats() {
  const xp = totalXp();
  const completed = getCompleted().map(([, record]) => record);
  const level = Math.floor(xp / 100) + 1;
  return { xp, level, streak: currentStreak(), completed, categories: new Set(completed.map(record => record.category)) };
}
function titleFor(level) {
  if (level >= 10) return '伝説のクエストマスター';
  if (level >= 7) return '星渡りの冒険者';
  if (level >= 5) return '習慣の守り人';
  if (level >= 3) return '頼れる冒険者';
  if (level >= 2) return '日常の旅人';
  return 'はじまりの冒険者';
}
function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}
function renderHeader() {
  const now = new Date();
  $('#todayDate').textContent = new Intl.DateTimeFormat('ja-JP', { month: 'long', day: 'numeric', weekday: 'short' }).format(now);
  $('#seasonDate').textContent = new Intl.DateTimeFormat('en-US', { month: 'short', year: 'numeric' }).format(now).toUpperCase();
  document.body.classList.toggle('light', state.lightMode);
  $('#themeIcon').textContent = state.lightMode ? '☾' : '☼';
  $('#themeToggle').setAttribute('aria-label', state.lightMode ? 'ダークモードへ切り替え' : 'ライトモードへ切り替え');
}
function renderProfile() {
  const stats = profileStats();
  const progress = stats.xp % 100;
  $('#heroLevel').textContent = stats.level;
  $('#playerTitle').textContent = titleFor(stats.level);
  $('#xpNumbers').textContent = `${progress} / 100 XP`;
  $('#xpPercent').textContent = `${progress}%`;
  $('#xpProgress').style.width = `${progress}%`;
  $('#streakCount').textContent = `${stats.streak}日`;
  $('#completedCount').textContent = stats.completed.length;
}
function renderToday(){
 const renderList=(period,host)=>{const missions=activeMissions(period),statuses=state.questCycle[period].tasks;if(!missions.length){host.innerHTML='<div class="library-empty">クエストがありません。クエストボードから追加してください。</div>';return}host.innerHTML=missions.map(m=>{const s=statuses[m.id]||'pending',labels={pending:'挑戦中',completed:'達成済み',missed:'見送り'};return '<article class="quest-item '+s+'"><div class="quest-item-main"><span class="mission-icon">'+(CATEGORIES[m.category]||'◇')+'</span><div class="quest-item-copy"><strong>'+escapeHtml(m.title)+'</strong><small>'+escapeHtml(m.category)+(m.description?' · '+escapeHtml(m.description):'')+'</small></div><span class="library-xp">+'+Number(m.xp)+' XP</span></div><div class="quest-item-actions">'+(s==='pending'?'<button class="complete-button" data-action="complete" data-period="'+period+'" data-id="'+escapeHtml(m.id)+'" type="button">✓ 達成</button><button class="miss-button" data-action="miss" data-period="'+period+'" data-id="'+escapeHtml(m.id)+'" type="button">見送る</button>':'<span class="quest-item-status '+s+'">'+labels[s]+'</span>')+'</div></article>'}).join('')};
 renderList('daily',$('#dailyQuestList'));renderList('weekly',$('#weeklyQuestList'));const n=state.questCycle.daily.resetCount;$('#dailyResetCount').textContent='本日のリセット '+n+' / 2';$('#resetDailyQuests').disabled=n>=2;$('#resetDailyQuests').textContent=n>=2?'本日のリセット回数を使い切りました':'未達成クエストをリセット ('+(2-n)+'回)';
}
function renderLibrary(){
 const host=$('#missionList');if(!state.missions.length){host.innerHTML='<div class="library-empty">クエストがありません。「ミッションを作る」から追加しよう。</div>';return}
 host.innerHTML=state.missions.map(m=>'<article class="library-item"><span class="mission-icon">'+(CATEGORIES[m.category]||'◇')+'</span><div class="library-info"><strong>'+escapeHtml(m.title)+'</strong><small>'+escapeHtml(m.category)+' · '+(m.period==='weekly'?'ウィークリー':'デイリー')+'</small></div><span class="library-xp">+'+Number(m.xp)+' XP</span><div class="library-actions"><button class="mini-action" data-action="edit" data-id="'+escapeHtml(m.id)+'" type="button" aria-label="編集" title="編集">✎</button><button class="mini-action delete" data-action="delete" data-id="'+escapeHtml(m.id)+'" type="button" aria-label="削除" title="削除">×</button></div></article>').join('');
}
function renderAchievements() {
  const stats = profileStats();
  const unlocked = ACHIEVEMENTS.filter(achievement => achievement.test(stats));
  $('#achievementCount').textContent = `${unlocked.length} / ${ACHIEVEMENTS.length}`;
  $('#achievementList').innerHTML = ACHIEVEMENTS.map(achievement => {
    const isUnlocked = achievement.test(stats);
    return `<article class="achievement ${isUnlocked ? 'unlocked' : 'locked'}"><span class="achievement-icon">${achievement.icon}</span><div class="achievement-text"><strong>${achievement.title}</strong><small>${achievement.detail}</small></div>${isUnlocked ? '<span class="achievement-check">✓</span>' : ''}</article>`;
  }).join('');
}
function renderHistory(){
 const entries=Object.entries(state.records).map(([date,r])=>({date,...r})).concat(state.cycleLogs||[]).sort((a,b)=>(b.finishedAt||b.date).localeCompare(a.finishedAt||a.date));
 $('#historyCount').textContent=entries.length+'件';if(!entries.length){$('#historyList').innerHTML='<div class="history-empty">ここに冒険の記録が増えていきます。</div>';return}
 $('#historyList').innerHTML=entries.slice(0,8).map(r=>'<article class="history-item"><span class="history-date">'+formatDate(r.date)+'</span><div class="history-main"><strong>'+escapeHtml(r.title)+'</strong><small>'+escapeHtml(r.category)+(r.status==='completed'?' · +'+Number(r.xp)+' XP':'')+'</small></div><span class="history-result '+r.status+'">'+(r.status==='completed'?'達成':r.status==='missed'?'見送り':'挑戦中')+'</span></article>').join('');
}
function render() { ensureQuestCycles(); renderHeader(); renderProfile(); renderToday(); renderLibrary(); renderAchievements(); renderHistory(); }
function decideQuest(period,id,status){
 const mission=state.missions.find(item=>item.id===id),cycle=state.questCycle[period];if(!mission||!cycle||cycle.tasks[id]!=='pending')return;
 cycle.tasks[id]=status;if(status==='completed')state.cycleLogs.push({date:dateKey(),period,missionId:id,title:mission.title,category:mission.category,xp:Number(mission.xp),status:'completed',finishedAt:new Date().toISOString()});
 saveState();render();if(status==='completed')toast('クエスト達成！ +'+Number(mission.xp)+' XP');
}
function handleQuestAction(event){const b=event.target.closest('[data-action]');if(b)decideQuest(b.dataset.period,b.dataset.id,b.dataset.action==='complete'?'completed':'missed')}
function resetDailyQuests(){const daily=state.questCycle.daily;if(daily.resetCount>=2){toast('本日のリセット回数を使い切りました');return}Object.keys(daily.tasks).forEach(id=>{if(daily.tasks[id]!=='completed')daily.tasks[id]='pending'});daily.resetCount++;saveState();render();toast('未達成のデイリークエストをリセットしました')}
function decideToday(status) {
  const record = state.records[dateKey()];
  if (!record || record.status !== 'pending') return;
  record.status = status; record.finishedAt = new Date().toISOString();
  saveState(); render();
  if (status === 'completed') toast(`クエスト達成！ +${Number(record.xp)} XP`);
  else toast('記録しました。明日また挑戦しよう。');
}
function openMissionEditor(mission = null) {
  editingId = mission?.id || null;
  $('#dialogTitle').textContent = mission ? 'クエストを編集' : 'クエストを作成';
  $('#missionTitle').value = mission?.title || '';
  $('#missionCategory').value = mission?.category || '健康';
  $('#missionXp').value = mission?.xp ?? 20;
  $('#missionDescription').value = mission?.description || '';
  $('#missionPeriod').value = mission?.period || 'daily';
  $('#formError').textContent = '';
  dialog.showModal(); $('#missionTitle').focus();
}
function saveMission(event){
 event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget).entries()),title=data.title.trim(),xp=Number(data.xp),period=data.period;
 if(!title){$('#formError').textContent='ミッション名を入力してください。';return}if(!Number.isInteger(xp)||xp<5||xp>100){$('#formError').textContent='経験値は5から100までの整数で設定してください。';return}
 if(state.missions.filter(m=>m.period===period&&m.id!==editingId).length>=5){$('#formError').textContent=(period==='daily'?'デイリー':'ウィークリー')+'は5件まで設定できます。';return}
 const mission={id:editingId||'custom-'+Date.now(),title,category:data.category,description:data.description.trim(),xp,period};
 if(editingId)state.missions=state.missions.map(item=>item.id===editingId?mission:item);else state.missions.unshift(mission);
 ensureQuestCycles();saveState();dialog.close();render();toast(editingId?'クエストを更新しました':'新しいクエストを追加しました');editingId=null;
}
window.addDailyQuestMission = function(mission) {
 const period=state.missions.filter(m=>m.period==='daily').length<5?'daily':state.missions.filter(m=>m.period==='weekly').length<5?'weekly':null;
 if(!period){toast('デイリーとウィークリーは各5件までです');return}
 state.missions.unshift({...mission,period});ensureQuestCycles();saveState();render();toast('検索結果からクエストを追加しました');
};;

function libraryAction(event) {
  const button = event.target.closest('[data-action]'); if (!button) return;
  const mission = state.missions.find(item => item.id === button.dataset.id); if (!mission) return;
  if (button.dataset.action === 'edit') { openMissionEditor(mission); return; }
  if (button.dataset.action === 'delete') {
    if (!confirm(`「${mission.title}」をクエストボードから削除しますか？`)) return;
    state.missions = state.missions.filter(item => item.id !== mission.id);
    saveState(); render(); toast('クエストを削除しました');
  }
}

$('#dailyQuestList').addEventListener('click', handleQuestAction);
$('#weeklyQuestList').addEventListener('click', handleQuestAction);
$('#resetDailyQuests').addEventListener('click', resetDailyQuests);
$('#addMission').addEventListener('click', () => openMissionEditor());
$('#missionList').addEventListener('click', libraryAction);
$('#missionForm').addEventListener('submit', saveMission);
$('#closeDialog').addEventListener('click', () => dialog.close());
$('#cancelDialog').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
$('#themeToggle').addEventListener('click', () => { state.lightMode = !state.lightMode; saveState(); renderHeader(); });
$('#resetData').addEventListener('click', () => {
  if (!confirm('クエスト履歴・経験値・カスタムミッションを消去し、初期状態に戻しますか？')) return;
  state = { version: 1, missions: normalizeMissions(structuredClone(DEFAULT_MISSIONS)), records: {}, cycleLogs: [], questCycle: null, lightMode: state.lightMode };
  saveState(); render(); toast('冒険の記録をリセットしました');
});
const questStyle=document.createElement('style');
questStyle.textContent='.quest-periods{display:grid;gap:20px}.quest-period{padding:16px;border:1px solid var(--line);border-radius:13px;background:var(--surface)}.quest-period .section-heading{margin-bottom:10px}.quest-list{display:grid;gap:8px}.quest-item{padding:12px;border:1px solid var(--line);border-radius:10px;background:var(--surface-2)}.quest-item-main{display:flex;align-items:center;gap:10px}.quest-item-copy{flex:1;min-width:0}.quest-item-copy strong{display:block;font-size:12px}.quest-item-copy small{display:block;color:var(--muted);font-size:9px;margin-top:4px}.quest-item-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:10px}.quest-item-status{font-size:10px}.quest-item-status.completed{color:var(--green)}.quest-item-status.missed{color:var(--muted)}.reset-quests{margin-top:10px}.reset-quests:disabled{opacity:.5;cursor:not-allowed}.quest-period .complete-button,.quest-period .miss-button{padding:7px 10px}';
render();
