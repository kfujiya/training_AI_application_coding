# Daily Quest

日々のやることをゲームのクエストに見立てて、達成記録・経験値・レベル・実績を残す小さなWebアプリです。HTML、CSS、JavaScriptのみで作ってあり、最初の利用にサーバーや外部APIは必要ありません。

## 起動方法

1. エクスプローラーで `C:\Users\shoty\DailyQuest` を開きます。
2. `index.html` をダブルクリックします。
3. 「今日のクエストを選ぶ」を押して、今日のミッションを決めます。
4. 達成したら「達成した！」、できなかった日は「今日は見送る」を押します。

ChromeまたはEdgeを推奨します。データはブラウザーの`localStorage`に保存されるため、同じブラウザー・同じWindowsユーザーのプロファイルで開いてください。ブラウザーの保存データを消すと記録も消えます。

## ファイルの役割

- `index.html`：画面の見出し、クエスト、進捗、実績、履歴、入力ダイアログの構造。
- `styles.css`：ゲーム風の配色、暗い/明るいテーマ、スマートフォン向けレイアウト。
- `app.js`：ミッション選択、達成・見送り、経験値・レベル・連続日数・実績、編集、保存と再読み込み。
- `yahoo.js`：Yahoo!ショッピングとYOLPの検索。Client IDはタブ内だけに保存します。
- `browser-smoke.cjs`：Chromeを使った操作確認スクリプト。通常の起動には不要です。

## 遊び方・ルール

- クエストは1日1つ選べます。選んだクエストは、その日の記録に保存されます。
- 達成するとクエストに設定した経験値を獲得します。100 XPごとにレベルが1上がります。
- 見送りは履歴に残りますが、経験値は増えず、その日の連続達成日数は0になります。
- 経験値と達成回数から称号と実績バッジを表示します。
- クエストボードでは初期ミッションの編集・削除、自分のミッションの追加ができます。履歴には当時のミッション内容が保存されます。
- 右上の太陽/月ボタンでテーマを切り替えます。記録リセットは確認後に初期化します。

## 確認テスト

Node.jsとGoogle Chromeがある開発環境では、PowerShellから次を実行できます。

```powershell
cd C:\Users\shoty\DailyQuest
node browser-smoke.cjs
```

タスク選択、達成、経験値・レベル・連続日数・実績・履歴、見送り、ミッション追加・編集・削除、テーマ保存、再読み込み後の復元を確認します。APIには接続しません。

## Yahoo! APIを使う

Daily Quest now has optional Yahoo! product and nearby place search. Set your Client ID in the app before searching.

### 商品検索

Yahoo!ショッピング「商品検索（v3）」は公式仕様に掲載されており、商品名のキーワード検索に使えます。リクエストは `https://shopping.yahooapis.jp/ShoppingWebService/V3/itemSearch` へのGETで、`appid`（Client ID）と`query`を指定し、商品情報はJSONの`hits`に返ります。商品検索はYahoo! ID連携のアクセストークンを必要としません。[商品検索仕様](https://developer.yahoo.co.jp/webapi/shopping/v3/itemsearch.html) [ショッピングAPI一覧](https://developer.yahoo.co.jp/webapi/shopping/)

利用にはYahoo!デベロッパーネットワークでアプリケーション登録とClient ID取得が必要です。既存のIDに利用権限がない場合は、FAQにある権限確認と新規アプリ登録手順を確認します。注文・問い合わせ等のストア運営APIは別申請ですが、商品検索とは別の機能です。[ショッピングAPI申請案内](https://developer.yahoo.co.jp/webapi/shopping/help/application.html) [FAQ](https://developer.yahoo.co.jp/webapi/shopping/faq.html)

制限は公式ページ間に記載差があります。商品検索仕様ページは短時間の連続アクセスで一時制限されることがあるとして1クエリー/秒を案内しています。一方、2022年の仕様変更告知はClient IDごとに30リクエスト/分とHTTP 429を案内しています。連携する場合は控えめな30回/分以下を採用し、429時は待って再試行する設計が安全です。[商品検索仕様](https://developer.yahoo.co.jp/webapi/shopping/v3/itemsearch.html) [利用制限変更告知](https://developer.yahoo.co.jp/changelog/2022-05-20-shopping294.html)

### 地図・お出かけ検索

Yahoo! Open Local Platform（YOLP）の公式一覧では、地図・地域情報APIが掲載されています。たとえばローカルサーチAPIは店舗・施設をキーワードや地点周辺で検索でき、ジオコーダAPIは住所を緯度・経度へ変換できます。どちらもClient IDを`appid`として渡します。ローカルサーチはJSONまたはJSONP、ジオコーダはJSONP形式の説明が掲載されています。[YOLP一覧と利用条件](https://developer.yahoo.co.jp/webapi/map/) [ローカルサーチ仕様](https://developer.yahoo.co.jp/webapi/map/openlocalplatform/v1/localsearch.html) [ジオコーダ仕様](https://developer.yahoo.co.jp/webapi/map/openlocalplatform/v1/geocoder.html)

YOLPの利用条件には1アプリあたり1日5万リクエストまでと記載されています。規約には検索語・住所・緯度経度などをYahoo!へ送る場合の扱い、情報の保存/キャッシュ禁止、地図上の表示改変禁止等もあります。位置情報を送信する機能を加える前に、利用者に目的と送信内容を説明する設計が必要です。YOLPの一部API（ルート沿い検索、カセットサーチ）は2022年に終了しています。[YOLP利用条件](https://developer.yahoo.co.jp/webapi/map/) [提供終了のお知らせ](https://developer.yahoo.co.jp/changelog/2022-05-13-map.html)

### クレジットとブラウザー制約

Yahoo! APIを使う公開アプリには、公式指定のYahoo!クレジットを規定HTMLのままアプリ下部に表示する必要があります。[クレジット表示規定](https://developer.yahoo.co.jp/attribution/)

商品検索は静的アプリからの通信がブラウザーのCORS制限で失敗する場合があります。失敗時はエラーを表示し、架空の検索結果は表示しません。公開時はClient IDをブラウザーへ出さないサーバー中継を検討してください。


Setup: In the Yahoo! Developer Network app details, copy the Client ID (never enter a Client Secret). Paste it into the Yahoo! Client ID field and click “このタブで使用”. The ID is kept in sessionStorage until the tab closes. Place search sends the entered address and query to Yahoo!. The official Yahoo! attribution appears after an API request.