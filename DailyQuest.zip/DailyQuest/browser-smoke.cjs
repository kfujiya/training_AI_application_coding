const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const assert = require('node:assert/strict');
const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const pageUrl = 'file:///C:/Users/shoty/DailyQuest/index.html';
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'dailyquest-chrome-'));
let chrome, socket, idCounter = 0;
const waiting = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function freePort() { const server=net.createServer(); await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve)); const port=server.address().port; await new Promise(resolve=>server.close(resolve)); return port; }
async function getPageTarget(port) { for(let i=0;i<60;i++){try{const targets=await(await fetch(`http://127.0.0.1:${port}/json`)).json();const page=targets.find(t=>t.type==='page'&&t.url.startsWith('file:'));if(page)return page;}catch{} await sleep(200);} throw Error('Chrome test page not found'); }
function cdp(method,params={}) { const id=++idCounter; socket.send(JSON.stringify({id,method,params})); return new Promise((resolve,reject)=>waiting.set(id,{resolve,reject})); }
async function evaluate(expression) { const response=await cdp('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true}); if(response.exceptionDetails) throw Error(response.exceptionDetails.text); return response.result?.value; }
async function ready(){for(let i=0;i<50;i++){if(await evaluate('document.readyState==="complete"&&!!document.querySelector("#todayMission")'))return;await sleep(100);}throw Error('Daily Quest did not load');}
function check(condition,label){assert.ok(condition,label);console.log('PASS '+label);}
(async()=>{
 const port=await freePort(); chrome=spawn(chromePath,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check',`--remote-debugging-port=${port}`,`--user-data-dir=${profile}`,pageUrl],{stdio:'ignore'});
 const target=await getPageTarget(port); socket=new WebSocket(target.webSocketDebuggerUrl);
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 socket.addEventListener('message',event=>{const msg=JSON.parse(event.data);if(!msg.id)return;const waiter=waiting.get(msg.id);if(!waiter)return;waiting.delete(msg.id);msg.error?waiter.reject(Error(msg.error.message)):waiter.resolve(msg.result);});
 await cdp('Runtime.enable'); await cdp('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true}); await ready();
 await evaluate('localStorage.removeItem("dailyQuest.v1");location.reload()'); await sleep(250); await ready();
 check(await evaluate('document.querySelector("#todayMission").classList.contains("is-empty")&&document.querySelectorAll(".library-item").length===10'),'initial view and default quests');
 check(await evaluate('document.documentElement.scrollWidth===390'),'mobile width has no horizontal overflow');
 await cdp("Emulation.setDeviceMetricsOverride",{width:1280,height:900,deviceScaleFactor:1,mobile:false});
 check(await evaluate('document.documentElement.scrollWidth<=1280'),'desktop width has no horizontal overflow');
 await cdp("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await evaluate('Math.random=()=>0;document.querySelector("#chooseMission").disabled=false;document.querySelector("#chooseMission").click()');
 check(await evaluate('document.querySelector("#todayMission").textContent.includes("近所を15分散歩する")&&document.querySelector("#todayStatus").textContent==="挑戦中"'),'random daily mission selection');
 await evaluate('document.querySelector(".complete-button").click()');
 check(await evaluate('document.querySelector("#xpNumbers").textContent.includes("20 / 100")&&document.querySelector("#heroLevel").textContent==="1"'),'XP reward and level progress');
 check(await evaluate('document.querySelector("#completedCount").textContent==="1"&&document.querySelector("#streakCount").textContent==="1日"'),'completed count and streak');
 check(await evaluate('document.querySelector("#historyList").textContent.includes("達成")&&document.querySelector("#achievementCount").textContent==="1 / 7"'),'history and first achievement');

 await evaluate('document.querySelector("#addMission").click();document.querySelector("#missionTitle").value="ユーザーミッション";document.querySelector("#missionCategory").value="学び";document.querySelector("#missionXp").value="100";document.querySelector("#missionDescription").value="テスト説明";document.querySelector("#missionForm").dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))');
 check(await evaluate('Array.from(document.querySelectorAll(".library-item")).some(item=>item.textContent.includes("ユーザーミッション")&&item.textContent.includes("+100 XP"))'),'custom mission creation');
 await evaluate('Array.from(document.querySelectorAll(".library-item")).find(item=>item.textContent.includes("ユーザーミッション")).querySelector("[data-action=edit]").click();document.querySelector("#missionTitle").value="編集済みミッション";document.querySelector("#missionXp").value="100";document.querySelector("#missionForm").dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))');
 check(await evaluate('Array.from(document.querySelectorAll(".library-item")).some(item=>item.textContent.includes("編集済みミッション")&&item.textContent.includes("+100 XP"))'),'custom mission editing');
 await evaluate('document.querySelector("#addMission").click();document.querySelector("#missionTitle").value="削除テスト";document.querySelector("#missionXp").value="15";document.querySelector("#missionForm").dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))');
 await evaluate('window.confirm=()=>true;Array.from(document.querySelectorAll(".library-item")).find(item=>item.textContent.includes("削除テスト")).querySelector("[data-action=delete]").click()');
 check(await evaluate('!Array.from(document.querySelectorAll(".library-item")).some(item=>item.textContent.includes("削除テスト"))'),'custom mission deletion');

 await evaluate('document.querySelector("#themeToggle").click()');
 check(await evaluate('document.body.classList.contains("light")&&JSON.parse(localStorage.getItem("dailyQuest.v1")).lightMode'),'theme toggle and persistence');
 await evaluate('location.reload()'); await sleep(250); await ready();
 check(await evaluate('document.body.classList.contains("light")&&document.querySelector("#xpNumbers").textContent.includes("20 / 100")&&document.querySelector("#historyCount").textContent==="1件"'),'reload restores XP, history, and theme');

 await evaluate('const RealDate=Date;window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[RealDate.now()+86400000]))}static now(){return RealDate.now()+86400000}};Math.random=()=>0;document.querySelector("#chooseMission").disabled=false;document.querySelector("#chooseMission").click()');
 check(await evaluate('document.querySelector("#todayStatus").textContent==="挑戦中"'),'next-day mission can be selected');
 await evaluate('document.querySelector(".complete-button").click()');
 check(await evaluate('document.querySelector("#heroLevel").textContent==="2"&&document.querySelector("#xpNumbers").textContent.includes("20 / 100")&&document.querySelector("#streakCount").textContent==="2日"'),'level-up and two-day streak');
 await evaluate('window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[RealDate.now()+2*86400000]))}static now(){return RealDate.now()+2*86400000}};document.querySelector("#chooseMission").disabled=false;document.querySelector("#chooseMission").click()');
 await evaluate('document.querySelector(".miss-button").click()');
 check(await evaluate('document.querySelector("#todayStatus").textContent==="見送り"&&document.querySelector("#streakCount").textContent==="0日"'),'missed mission records and resets streak');
 check(await evaluate('document.querySelector("#xpNumbers").textContent.includes("20 / 100")&&Object.values(JSON.parse(localStorage.getItem("dailyQuest.v1")).records).filter(r=>r.status==="missed").length===1&&JSON.parse(localStorage.getItem("dailyQuest.v1")).records[Object.keys(JSON.parse(localStorage.getItem("dailyQuest.v1")).records).sort().at(-2)].status==="completed"'),'missed mission awards no XP and persists');
 check(await evaluate('!performance.getEntriesByType("resource").some(r=>r.name.includes("yahooapis.jp"))'),'no Yahoo API requests are made');
 console.log('All Daily Quest browser checks passed.');
})().catch(error=>{console.error(error);process.exitCode=1;}).finally(()=>{try{socket?.close()}catch{}try{chrome?.kill()}catch{}setTimeout(()=>{try{fs.rmSync(profile,{recursive:true,force:true})}catch{}},900);});
