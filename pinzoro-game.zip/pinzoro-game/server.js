﻿const express = require('express');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const port = Number(process.env.PORT || 3000);
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ...(process.env.DATABASE_URL ? {} : {
    host: process.env.PGHOST || 'localhost',
    port: Number(process.env.PGPORT || 5432),
    database: process.env.PGDATABASE || 'pinzoro',
    user: process.env.PGUSER || 'postgres',
    password: process.env.PGPASSWORD || 'postgres'
  })
});

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

async function initialize() {
  await pool.query(`CREATE TABLE IF NOT EXISTS pinzoro_games (
    id BIGSERIAL PRIMARY KEY,
    started_at TIMESTAMPTZ NOT NULL,
    finished_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    result TEXT NOT NULL CHECK (result IN ('Successed', 'Failed')),
    duration_seconds INTEGER NOT NULL CHECK (duration_seconds >= 0),
    rolls JSONB NOT NULL DEFAULT '[]'::jsonb
  )`);
  await pool.query("ALTER TABLE pinzoro_games ADD COLUMN IF NOT EXISTS dice_count INTEGER NOT NULL DEFAULT 9 CHECK (dice_count IN (3, 6, 9))");
  await pool.query("UPDATE pinzoro_games SET dice_count = jsonb_array_length(rolls->0) WHERE jsonb_typeof(rolls) = 'array' AND jsonb_array_length(rolls->0) IN (3, 6, 9)");
}

app.get('/api/scores', async (_req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT id, started_at, result, duration_seconds, dice_count FROM pinzoro_games ORDER BY started_at DESC LIMIT 100'
    );
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'スコアを読み込めませんでした。' });
  }
});

app.post('/api/games', async (req, res) => {
  const { startedAt, result, durationSeconds, rolls, diceCount } = req.body || {};
  if (!startedAt || !['Successed', 'Failed'].includes(result) ||
      !Number.isInteger(durationSeconds) || durationSeconds < 0 ||
      !Array.isArray(rolls) || rolls.length > 10000 || ![3, 6, 9].includes(diceCount) ||
      rolls.some(row => !Array.isArray(row) || row.length !== diceCount || row.some(n => !Number.isInteger(n) || n < 1 || n > 6))) {
    return res.status(400).json({ error: 'ゲーム記録の内容が正しくありません。' });
  }
  const start = new Date(startedAt);
  if (Number.isNaN(start.getTime()) || start.getTime() > Date.now()) {
    return res.status(400).json({ error: '開始日時が正しくありません。' });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO pinzoro_games (started_at, result, duration_seconds, dice_count, rolls)
       VALUES ($1, $2, $3, $4, $5::jsonb)
       RETURNING id, started_at, result, duration_seconds, dice_count`,
      [start, result, durationSeconds, diceCount, JSON.stringify(rolls)]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: '記録を保存できませんでした。PostgreSQLの接続を確認してください。' });
  }
});
app.get('/api/games/:id', async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: '記録IDが正しくありません。' });
  try {
    const { rows } = await pool.query(
      'SELECT id, started_at, result, duration_seconds, dice_count, rolls FROM pinzoro_games WHERE id = $1',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: '記録が見つかりません。' });
    res.json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: '記録を読み込めませんでした。' });
  }
});

initialize().then(() => {
  app.listen(port, () => console.log(`ピンゾロゲーム: http://localhost:${port}`));
}).catch(error => {
  console.error('PostgreSQLの初期化に失敗しました。接続設定を確認してください。', error.message);
  process.exit(1);
});





