﻿# ピンゾロゲーム

9個のサイコロを振り、すべて「1」にそろえるゲームです。投了すると Failed として終了します。ゲームの開始日時・結果・クリアまでの時間・各投擲の出目をPostgreSQLへ保存します。

## 起動方法

1. Docker Desktopを起動し、このフォルダで `docker compose up -d` を実行します。
2. `npm install` を実行します。
3. `npm start` を実行します。
4. ブラウザで http://localhost:3000 を開きます。

初期設定では、PostgreSQLは `localhost:5432`、データベース・ユーザー・パスワードは `pinzoro` / `postgres` / `postgres` です。`DATABASE_URL` または `PGHOST`、`PGPORT`、`PGDATABASE`、`PGUSER`、`PGPASSWORD` の環境変数で変更できます。テーブルはサーバー起動時に自動作成されます。
